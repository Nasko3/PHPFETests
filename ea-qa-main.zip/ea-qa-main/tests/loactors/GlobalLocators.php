<?php

namespace Locators;

/**
 * Class GlobalLocators
 * @package Locators
 */
class GlobalLocators
{
    //demo site locators
    public static $softDemo = "//h1[text()='iMX software demo']";
    public static $firstName = "//label[@for='first_name']/following-sibling::input[1]";
    public static $lastName = "//label[@for='last_name']/following-sibling::input[1]";
    public static $email = "//label[@for='email']/following-sibling::input[1]";
    public static $company = "//label[@for='company']/following-sibling::input[1]";
    public static $business = "//*[@id='business']/option[5]";
    public static $country = "//div[@class='flag-dropdown']//div";
    public static $countryInput = "//input[@data-error='Please choose your country']";
    public static $capthaLocCont = "//*[@id=\"demoForm\"]/div[9]/div/div/div/iframe";
    public static $capthaLocInner = "(//div[contains(@class, 'recaptcha-checkbox')])[1]";
    public static $checkbox = "//div[@class='checkbox-inline']//input[1]";
    public static $submitBtn = "//button[@type='submit']//i[1]";
    public static $SuccessText = "//div[text()[normalize-space()='Thank you for the request! We will get back to you soon!']]";

    //public static $text = "//*[text()='$$']";

    public static $SSOLogin = "(//div[@class='center']//div)[2]";
    public static $UMLogo = "//div[@class='col s12']//img[1]";
    public static $PasswdLogo = "//a[@href='/passwd/login?sso_login=true']";

    /* Login/UserManagment Locators */
    public static $loginUserInput = "//div[@class='input-field']//input";
    public static $loginPassInput = "(//div[@class='input-field']//input)[2]";
    public static $loginButton = "//button[contains(text(), 'Login')]";
    public static $userManagment = "//img[@alt='User Management']";
    public static $userManagmentLogo = "//img[@src='/assets/images/logo.png']";
    public static $PasswdAppBtn= "//a[@href='/passwd/login?sso_login=true']";


    /*Locator for authenticating before enter in app */
    public static $userLogo = " //div[@class='chip']//b[1]";
    public static $LogWithAnotherUsr = "(//div[@class='center']//a)[2]";

    /*Passwd tool app Locators */
    public static $PasswdToolAppLogo = "//a[@id='logo-container']//img[1]";
    public static $PasswdCredentialOSAccessTab = "//a[@href='/passwd/credential-os-access']";
    public static $PasswdCredentialOSAccInputF = "//div[contains(@class,'input-field col')]//label[1]";
    public static $PasswdCredentialAccProject = "//div[contains(@class,'input-field col')]//input[1]";
    public static $PasswdCredentialAccBankInterProject = "(//ul[@class='autocomplete-content dropdown-content']//span)[2]";
    public static $PasswdCredentialAccBankInterProjectRequiredIns = "//table[contains(@class,'highlight responsive-table')]/tbody[1]/tr[1]/td[10]/a[1]/i[1]";
    public static $PasswdCredentialAccBankInterProjectReason = "(//div[contains(@class,'input-field col')]//label)[2]";
    public static $PasswdCredentialAccBankInterProjectReasonInputF = "//label[text()='Projects']/following::textarea";
    public static $PasswdCrAccBankInterProjectCrtTaskBtn = "//button[text()=' Create Task ']";
    public static $PasswdCrAccBankInterProjectCloseBtn = "//div[@class='modal-footer']//a[1]";
    public static $PasswdAppExitBtn = "(//ul[@class='right hide-on-med-and-down']//i)[2]";
    public static $PasswdAccessControlTab = "(//a[@class='collapsible-header'])[3]";
    public static $PasswdAccessControlTabCredentialAccControlSubtab = "//a[@href='/passwd/credential-access-control']";//this down is how to use user to locate it among requests but it must be single result
    public static $PasswdAccessControlTabCredentialAccControlSubtabAndApprove = "(//a[@data-tooltip='Approve']//i)[1]";
    public static $PasswdAccessControlTabCredentialAccControlSubtabAndReject = "(//a[@data-tooltip='Reject']//i)[1]";
    public static $PasswdAccessControlTabCredentialAccControlImxProdRequest = "//*[contains(text(),'imxprod')]/following-sibling::td[9]/a[1]";
    public static $PasswdAccessControlTabCredentialAccAsterix = "//td[text()='*************']";
    public static $PasswdAccessControlTabCredentialAccControlImxProdTimedAccControl = "//*[contains(text(),'imxprod')]/following-sibling::td[9]/a[3]";
    public static $PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlCheckbox = "//div[contains(@class,'input-field col')]//span[1]";
    public static $PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlConfirm = "//div[@class='modal-footer']//button[1]";
    public static $PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlCloseBtn= "//div[@class='modal-footer']//a[1]";
    public static $PasswdAccessControlTabCredentialAccControlImxProdTime = "//input[@type='number']";


    /*DevOps app Locators */
    public static $DevOpsApp = "//a[contains(text(),'DevOps')]";
    public static $DevOpsLogo = "//img[@alt='DevOps Management']";
    public static $DevOpsPASDropdown = ['link' => 'PAS'];
    public static $DevOpsPASDropdown2 = "(//a[@class='collapsible-header'])[1]";
    public static $DevOpsIMXBeTab = "//a[@href='/devops/imx_be/dashboard']";
    public static $DevOpsIMXFeTab = "//a[@href='/devops/imx_fe/dashboard']";
    public static $DevOpsDemosTabDashboard = "//a[@href='/devops/demos/dashboard']";
    public static $DevOpsDemosTabDemos = "//a[@href='/devops/demos/list']";
    public static $DevOpsPasTabDevOpsMatrix = "//a[@href='/devops/pas/configurations']";
    public static $DevOpsPasTabExtranet = "//a[@href='/devops/extranet/dashboard']";
    public static $DevOpsPasTabSOA = "//a[@href='/devops/pas/soa-modification']";

    public static $devOpsBoard = "//a[@href='/devops/$$/dashboard']";
    public static $DevOpsConfig = "//a[@href='/devops/$$/configurations']";
    //tab Extranet
    public static $devOpsTabExtranetBtnCreateBuild = "//button[text()=' New build ']";
    public static $DevOpsTabExtranetCreateBuildFieldBrunch = "(//input[@class='autocomplete'])[1]";
    public static $DevOpsTabExtranetCTRBuildFieldClient = "(//input[@class='autocomplete'])[2]";
    public static $DevOpsTabExtranetCTRBuildFieldInstance = "//input[@data-target='autocomplete-options-3dcd17d5-7bde-70ba-6bba-4f9ffb1c3d25']";
    public static $DevOpsTabExtranetCTRBuildDropDownDeployOn = "//span[text()=' Tomcat 9.0.53 jdk8 ']";
    public static $DevOpsTabExtranetBtnStartCrtBld = "//button[@class='waves-effect btn']";
    //tab Debiteur
    public static $DevOpsTabDebiteurBtnNewBld = "//div[@class='col s12']//button[1]";
    public static $DevOpsTabDebiteurFldBranch = "//label[text()='Branch']";
    public static $DevOpsTabDebDrDownBranch = "//span[text()='BOC_DB_GROM']";
    public static $DevOpsTabDebDrDownClient = "(//i[contains(@class,'material-icons prefix')]/following-sibling::input)[3]";
    public static $DevOpsTabDebDrDownBranchBochio = "(//ul[@class='autocomplete-content dropdown-content']//span)[2]";
    public static $DevOpsTabDebiteurFldInstance = "(//input[@class='autocomplete'])[3]";
    public static $DevOpsTabDebDrDownInstance = "(//span[text()='hawk'])[1]";
    public static $DevOpsTabDebStartBtn = "//button[@class='waves-effect btn']";
    public static $DevOpsTabDebStoptBtnOnRunningBuild = "//a[@data-tooltip='Stop']//i[1]";
    public static $DevOpsTabDebStoppedBuild = "//span[text()='stopped']";
    public static $DevOpsTabDebRunningBuild = "//span[text()='running']";
    public static $DevOpsTabDebDownloadBuild = "//a[@data-tooltip='Download']//i[1]";
    public static $DevOpsTabDebRemoveBtn = "//a[@data-tooltip='Remove']//i[1]";
    public static $DevOpsTabDebRemovePopUpBtn = "//button[text()=' Remove ']";
}
