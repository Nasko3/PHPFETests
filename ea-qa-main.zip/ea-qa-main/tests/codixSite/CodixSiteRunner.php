<?php

namespace codixSite;

use Illuminate\Console\Command;


class CodixSiteRunner extends Command
{

   // $NavigateToDemoSite = new NavigateToDemoSite();
    /**
     * The console command name.
     *
     * @var string
     */
protected $signature = "check:requestForDemo";

// /*
// * @var CodixSiteCest
// */
// public $cest;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Enter in Codix site and navigate to request for demo page, then fill required fields and send it";

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        echo "---------------";
        $test = exec("php vendor/bin/codecept run --steps -g CodixSiteCest");
        echo $test;
    }

}