<?php

namespace tests\codixSite;

use \AcceptanceTester;
use Facebook\WebDriver\WebDriverKeys;
use Locators\GlobalLocators;
use Models\AcceptanceCest;
use Params\GlobalParams;
use \codixSite;

    /**
     * @group CodixSiteCest
     * 
     */
class CodixSiteCest extends AcceptanceCest
{

    protected string $nameOf;

    public function navigateToDemoSite(AcceptanceTester $I)
    {
        $I->amOnUrl('https://kardam.codixfr.private:4701/en/software/imx-software-demo');
        $I->waitForElementVisible(GlobalLocators::$softDemo, GlobalParams::MID_WAIT);
        $I->wait(GlobalParams::MID_WAIT);
    }
    public function enterRequirements(AcceptanceTester $I)
    {
        $this->nameOf = "Test" . time();
        $I->fillField(GlobalLocators::$firstName, 'Test');
        $I->wait(GlobalParams::MID_WAIT);
        $I->fillField(GlobalLocators::$lastName, 'Test');
        $I->wait(5);
        $I->fillField(GlobalLocators::$email, $this->nameOf.'@gmail.com');
        $I->wait(GlobalParams::MID_WAIT);
        $I->fillField(GlobalLocators::$company, 'CompanyCodixTestPuropuse');
        $I->wait(GlobalParams::MID_WAIT);
        $I->Click(GlobalLocators::$business);
        $I->wait(GlobalParams::MICRO_WAIT);
        $I->pressKey(GlobalLocators::$countryInput, WebDriverKeys::CONTROL . 'a');
        $I->pressKey(GlobalLocators::$countryInput, WebDriverKeys::DELETE);
        $I->wait(GlobalParams::WAIT);
        $I->fillField(GlobalLocators::$countryInput, 'Sweden (Sverige)');
        $I->wait(GlobalParams::WAIT);
        //here locators are needed for passing true captha checkbox
        $I->switchToIFrame(GlobalLocators::$capthaLocCont);
        $I->wait(GlobalParams::MID_WAIT);
        $I->see('not a robot');
        $I->wait(GlobalParams::MID_WAIT);
        $I->seeElement(GlobalLocators::$capthaLocInner);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$capthaLocInner);
        $I->wait(GlobalParams::MID_WAIT);
        $I->switchToIFrame();
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->scrollTo(GlobalLocators::$checkbox);
        $I->checkOption(GlobalLocators::$checkbox);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$submitBtn);
        $I->wait(GlobalParams::LONG_WAIT);
        $I->waitForElementVisible(GlobalLocators::$SuccessText);
    }

}