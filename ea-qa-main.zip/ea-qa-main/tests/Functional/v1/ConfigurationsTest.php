<?php

class ConfigurationsTest extends RestTestCase
{
    protected $uri        = 'v1/pas/configurations';
    protected $table      = 'extranet_configurations';
    protected $primaryKey = 'id';

    /**
     * Get request data
     *
     * @return array
     */
    protected function getData()
    {
        return [
            'project' => $this->faker()->word,
            'project_type' => $this->faker()->randomElement(['migration', 'new']),
            'app_type' => $this->faker()->randomElement(['extranet', 'debiteur']),
            'app_version' => $this->faker()->word,
            'delivery_chain' => $this->faker()->word,
            'dev_instance' => $this->faker()->word,
            'val_instance' => $this->faker()->word,
            'deploy_dev_instance' => $this->faker()->word,
            'deploy_val_instance' => $this->faker()->word,
            'branch' => $this->faker()->word,
            'prefix' => $this->faker()->word,
            'servlet_container' => "TOMCAT 8.5.14",
            'jdk' => $this->faker()->randomFloat(),
            'jre' => $this->faker()->randomFloat(),
            'additional_info' => $this->faker()->realText()
        ];
    }

    /**
     * Get request invalid data
     *
     * @param array $data
     * @return array
     */
    protected function getInvalidData(array $data)
    {
        // Set invalid parameters
        $data['jdk'] = $this->faker()->realText(500);

        // Remove required parameters
        unset($data['project'], $data['dev_instance']);

        return $data;
    }

    /**
     * Get request update data
     *
     * @param array $data
     * @return array
     */
    protected function getUpdateData(array $data)
    {
        // Change parameters
        $data['project'] = 'UPDATED_PROJECT';

        // Unset updated_on as it makes problems when connction is slow
        unset($data['updated_on']);

        return $data;
    }
}
