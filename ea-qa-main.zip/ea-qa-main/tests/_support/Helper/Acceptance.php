<?php

namespace Helper;

use Models\AcceptanceCest;
use Exception;
// use Codeception\PHPUnit\Constraint\WebDriver;

class Acceptance extends \Codeception\Module
{

    private $userLoc = "//input[@placeholder='Username']";
    private $passLoc = "//input[@placeholder='Password']";
    private $signInLoc = "//div[@class='login-form-button']//p";

    public function doLogin(\AcceptanceTester $I, $credentials, $newsession = false, $user = null, $password = null)
    {
        try {
            if ($user == null) {
                $user = $credentials ['usernameClient'];
            }

            // Map username to admin user type
            $userType = null;
            foreach (AcceptanceCest::$credentials as $credentialsUserType => $credentialsUser) {
                if ($credentialsUser['user'] === $user) {
                    $userType = $credentialsUserType;
                    break;
                }
            }

            // Use new logic if user type is mapped and no password is passed
            if ($userType && $password === null) {
                (new AcceptanceCest())->_login($I, $userType);
                return;
            }

            $I->comment('Login user ' . $user . ' is not mapped to AcceptanceCest::login');

            $I->wait(1);
            if ($password == null) {
                $password = $credentials ['goodpassClient'];
            }
            if ($newsession == false) {
                $I->comment('using same session');
                $I->amOnPage('');
                $I->wait(2);
                return;
            } else {
                $I->am('Guest');
                $I->wait(1);
                $I->comment('using new session');
                $I->amOnPage('/logout');
                $I->wait(2);
                $I->amGoingTo('login with username ' . $user);
                try {
                    $I->waitForElementVisible($this->userLoc, 10);
                } catch (\Exception $e) {
                    $I->reloadPage();
                }
                $I->waitForElementVisible($this->passLoc, 10);
                $I->fillField($this->userLoc, $user);
                $I->fillField($this->passLoc, $password);
                $I->waitForElementVisible($this->signInLoc, 30);
                $I->click($this->signInLoc);
                $I->expect('to be logged in with username ' . $user);
                $I->wait(2);
                $I->waitForElementVisible("//span[contains(text(), 'Administrative Interface')]", 10);
                if ($newsession == true) {
                    $I->saveSessionSnapshot('SESSION');
                }
            }
        } catch (\Exception $e) {
            $err = trim(var_export($I->grabTextFrom("//*[contains(@class, 'danger') or contains(@class, 'alert') or contains(@class, 'error')]"),
                true), ' \'');
            $I->comment('Following error appears: ' . $err);
            $I->assertTrue(false);
        }
    }

    public function doLogout(\AcceptanceTester $I)
    {
        $I->amGoingTo('logout');
        $I->switchToIFrame();
        $I->waitForElementVisible("//div[contains(@class,'username-dropdown-button')]//div", 10);
        $I->wait(1);
        $I->click("//div[contains(@class,'username-dropdown-button')]//div");
        $I->waitForElementVisible("//td[.='Sign Out']", 10);
        $I->wait(2);
        $I->click("//td[.='Sign Out']");
    }

    public function seeExceptionThrown($exception, $function)
    {
        try {
            $function ();
            return false;
        } catch (Exception $e) {
            if (get_class($e) == $exception) {
                return true;
            }
            return false;
        }
    }

    public function getCurrentUrl()
    {
        return $this->getModule('WebDriver')->webDriver->getCurrentURL();
    }



}
