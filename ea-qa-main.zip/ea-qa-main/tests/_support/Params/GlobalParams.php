<?php

namespace Params;

class GlobalParams
{
    /* Waits */
    public const MICRO_WAIT = 0.5;
    public const WAIT = 1;
    public const SHORT_WAIT = 2;
    public const WAIT_THREE = 3;
    public const MID_WAIT = 5;
    public const LONG_WAIT = 10;
    public const BIG_WAIT = 25;

    /* Messages */
    public const DELETE_MSG = 'Item deleted successfully';
    public const DUPLICATE = 'Duplicate entry';
    public const NO_DATA = 'There is no data to show in this view.';

    /* Accounts, Users */
    public const USER = '@codix.eu';
    //public const USER_CLIENT = '@codix.eu';
    

    /* Fields */
    //public const ACCOUNT_FIELD = 'Account';
    //public const ACCOUNT_CLASS_FIELD = 'account';
    //public const ACCOUNTS_CLASS = 'accounts';
    //public const USERNAME_FIELD = 'Username';
    //public const USERNAME_CLASS = 'username';
    //public const NAME_FIELD = 'Name';
    //public const NAME_CLASS = 'name';

    /* Modules */
    //public const CHANNELS = 'Channels';
    
}
