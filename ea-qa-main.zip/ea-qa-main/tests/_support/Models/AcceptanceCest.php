<?php

namespace Models;

use AcceptanceTester;
use Locators\GlobalLocators;
use Params\GlobalParams;

class AcceptanceCest
{
    const USER_ADMIN = 'test007';
    const USER_ORD = 'test001';

    const PASSWORD = 'test001';
    const PASSWORD_ADM = 'test007';

    /*
     * @var array Login credentials
     */
    public static $credentials = [
        self::USER_ADMIN => [
            'user' => 'test007',
            'pass' => self::PASSWORD_ADM,
        ],
        self::USER_ORD => [
            'user' => 'test001',
            'pass' => self::PASSWORD,
        ],
    ];


    protected function _login(AcceptanceTester $I)
    {
       // $I->amOnUrl('https://ea-dev.codixfr.private/applications');
    }

    protected function signInUserManagment(AcceptanceTester $I)
    {
        $I->amOnUrl('https://ea-dev.codixfr.private/login');
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$userManagment, GlobalParams::BIG_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, 'test001');
        $I->fillField(GlobalLocators::$loginPassInput, 'test001');
        $I->click(GlobalLocators::$loginButton);
    }

    protected function navigateToDevOpsApp(AcceptanceTester $I)
    {
        $I->waitForElementVisible(GlobalLocators::$DevOpsApp, GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsApp);
        $I->waitForElementVisible(GlobalLocators::$DevOpsLogo, GlobalParams::BIG_WAIT);
        $I->see('My Builds');
    }

    protected function navigateToPasswdTool(AcceptanceTester $I)
    {
        $I->waitForElementVisible(GlobalLocators::$PasswdAppBtn, GlobalParams::BIG_WAIT);
        $I->click(GlobalLocators::$PasswdAppBtn);
        $I->waitForElementVisible(GlobalLocators::$PasswdToolAppLogo, GlobalParams::BIG_WAIT);
        $I->wait(GlobalParams::MID_WAIT);
    }
    // TO DO :
    // protected function login(AcceptanceTester $I, $userType, $systemType): void
    // {
    //     $I->amOnPage('https://localhost/login');

    //          Validate user type
    //          if(!isset(self::$credentials[$userType])){
    //              $I->comment('Invalid user type');
    //              $I->assertTrue(false);
    //              return;
    //          }

    //     $username = self::$credentials[$userType]['user'];
    //     $password = self::$credentials[$userType]['pass'];

    //          //always start from logout page to

    //          $I->amOnPage('https://localhost/login');
    //          $I->waitForElementToBeVisible(GlobalLocators::$loginUserInput, GlobalParams::LONG_WAIT);
    //          $I->fillField(GlobalLocators::$loginUserInput, $username);
    //          $I->fillField(GlobalLocators::$loginPassInput, $password);
    //          $I->click(GlobalLocators::$loginButton);

    //          $I->amGoingTo('Click on DevOps system');
    //          $I->amOnPage('http://localhost:8088/devops/');
    //          $I->waitForElementToBeVisible(GlobalLocators::$loginUserInput, GlobalParams::LONG_WAIT);
    //          $I->fillField(GlobalLocators::$loginUserInput, $username);
    //          $this->waitAndClick($I, GlobalLocators::$loginButton);
    //          $I->waitForElement(GlobalLocators::$loginPassInput, GlobalParams::LONG_WAIT);
    //          $I->fillField(GlobalLocators::$loginPassInput, $password);
    //          $I->click(GlobalLocators::$loginButton);
    //          $I->waitForElementToBeVisible(GlobalLocators::$hederText, GlobalParams::LONG_WAIT);
    // }


    protected static function generateLocator($locator, $dynamicValue)
    {
        return \str_replace('$$', $dynamicValue, $locator);
    }

    protected function navigateModule(AcceptanceTester $I, array $path)
    {
        foreach ($path as $module) {
            // $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, $module));
            // $this->generateLocator(GlobalLocators::$devOpsBoard, $module);




            $I->click(['link' => $module]);
            $I->wait(GlobalParams::WAIT);
        }
    }
}
