<?php

namespace Acceptance;

use Illuminate\Console\Command;


class PasswdCestRunner extends Command
{

   
    /**
     * The console command name.
     *
     * @var string
     */
protected $signature = "check:PasswdCest";

// /*
// * @var PasswdCest
// */
// public $cest;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Navigate try Usermanagment tool to Passwd platform and test";

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        echo "---------------";
        $test = exec("php vendor/bin/codecept run --steps -g PasswdCest");
        echo $test;
    }

}