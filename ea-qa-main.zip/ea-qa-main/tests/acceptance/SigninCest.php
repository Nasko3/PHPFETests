<?php

namespace codixSite;

use \AcceptanceTester;
use Locators\GlobalLocators;
use Params\GlobalParams;
use \AcceptanceCest;

class SigninCest
{


    // public function _before(AcceptanceTester $I)
    // {
    //     // $I->amOnPage('/login');
    //     // $I->waitForElementVisible(GlobalLocators::$userManagmentLogo, GlobalParams::BIG_WAIT);
    //     // $this->signIn($I);
    //     // $this->signInUserManagment($I);
    //     // $this->navigateToDevOpsApp($I);
    // }

    // UserManagment Login
    private function signInUserManagment(AcceptanceTester $I)
    {
        $I->amOnPage('/login');
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$UMLogo);
        // $I->click(GlobalLocators::$SSOLogin);
        //$I->waitForElementVisible(GlobalLocators::$userManagment, GlobalParams::BIG_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, 'test001');
        $I->fillField(GlobalLocators::$loginPassInput, 'test001');
        $I->click(GlobalLocators::$loginButton);
        $I->waitForElementVisible(GlobalLocators::$userManagmentLogo, GlobalParams::MID_WAIT);
    }

    //navigation to DevOps api
    private function navigateToDevOpsApp(AcceptanceTester $I)
    {
        $I->waitForElementVisible(GlobalLocators::$DevOpsApp, GlobalParams::BIG_WAIT);
        $I->click(GlobalLocators::$DevOpsApp);
        $I->waitForElementVisible(GlobalLocators::$DevOpsLogo, GlobalParams::BIG_WAIT);
        $I->wait(GlobalParams::MID_WAIT);
        // $I->makeScreenshot();
    }

    private function navigateToPasswdTool(AcceptanceTester $I)
    {
        $I->waitForElementVisible(GlobalLocators::$PasswdLogo, GlobalParams::BIG_WAIT);
        $I->click(GlobalLocators::$PasswdLogo);
        $I->waitForElementVisible(GlobalLocators::$PasswdToolAppLogo, GlobalParams::BIG_WAIT);
        $I->wait(GlobalParams::MID_WAIT);
        // $I->makeScreenshot();
    }

}
