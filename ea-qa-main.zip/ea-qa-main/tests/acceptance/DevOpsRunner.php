<?php

namespace Acceptance;

use Illuminate\Console\Command;


class DevOpsRunner extends Command
{

   
    /**
     * The console command name.
     *
     * @var string
     */
protected $signature = "check:DevOpsCest";

// /*
// * @var DevOpsCest
// */
// public $cest;

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = "Navigate try Usermanagment tool to Dev Ops platform and test";

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        echo "---------------";
        $test = exec("php vendor/bin/codecept run --steps -g DevOpsCest");
        echo $test;
    }

}