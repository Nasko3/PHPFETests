<?php


namespace Acceptance;

use \AcceptanceTester;
use Facebook\WebDriver\WebDriverKeys;
use \Facebook\WebDriver\WebDriverBy;
use GlobIterator;
use Locators\GlobalLocators;
use Models\AcceptanceCest;
use Params\GlobalParams;
use phpDocumentor\Reflection\DocBlock\Tags\See;
use Exception;

class PasswdCest extends AcceptanceCest
{
    const USER_ORD = 'test001';
    const USER_ADMIN = 'test007';

    const PASSWORD = 'test001';
    const PASSWORD_ADM = 'test007';


    public function _before(AcceptanceTester $I)
    {
        $this->signInUserManagment($I);
        $this->navigateToPasswdTool($I);
    }
    // tests
    /**
     * @group PasswdCest
     * 
     */
    public function NavigateToCredentialOSAccessAndRequestAccessThanReject(AcceptanceTester $I)
    {
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccProject);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectRequiredIns);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectReason);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccBankInterProjectReasonInputF, "Test001");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCrtTaskBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->see("has been created and send.");
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCloseBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        // $I->click(GlobalLocators::$LogWithAnotherUsr);
        // $I->wait(GlobalParams::SHORT_WAIT);
        // $I->fillField(GlobalLocators::$loginUserInput, 'test007');
        // $I->fillField(GlobalLocators::$loginPassInput, 'test007');
        // $I->click(GlobalLocators::$loginButton);
        // $I->wait(GlobalParams::MID_WAIT);
        // $I->click(GlobalLocators::$PasswdAccessControlTab);
        // $I->wait(GlobalParams::SHORT_WAIT);
        // $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtab);
        // $I->wait(GlobalParams::SHORT_WAIT);
        // $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtabAndReject);
        // $I->wait(GlobalParams::SHORT_WAIT);
        // $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ADMIN);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD_ADM);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtabAndApprove);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ORD);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD);
        $I->wait(GlobalParams::WAIT);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->see(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdRequest);
        $I->see(GlobalLocators::$PasswdAccessControlTabCredentialAccAsterix);
        $I->wait(GlobalParams::MID_WAIT);
    }
    /**
     * @group PasswdCest
     * 
     */
    public function NavigateToCredentialOSAccessAndEnableTimedAccessThanRequestAndReject(AcceptanceTester $I)
    {
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ADMIN);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD_ADM);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccProject);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdTimedAccControl);
        $I->wait(GlobalParams::SHORT_WAIT);
        
        try{
            $I->executeJS("document.querySelector('.filled-in:checked').value");
        } catch (Exception $ex)
        {
            $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlCheckbox);
        }
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlConfirm);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdTimedAccControlCloseBtn);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ORD);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectRequiredIns);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectReason);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccBankInterProjectReasonInputF, "Test001");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdTime, "1");
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCrtTaskBtn);
        $I->wait(GlobalParams::BIG_WAIT);
        $I->See("was send.");
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCloseBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ADMIN);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD_ADM);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtabAndReject);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ORD);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->dontSee(GlobalLocators::$PasswdAccessControlTabCredentialAccAsterix);
        $I->wait(GlobalParams::MID_WAIT);
    }
    /**
     * @group PasswdCest
     * 
     */
    //login in Dbeaver and remove access after this method
    private function NavigateToCredentialOSAccessAndRequestAccessThanApprove(AcceptanceTester $I)
    {
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccProject);
        $I->wait(GlobalParams::MID_WAIT);
        // $I->click(GlobalLocators::$PasswdCredentialAccBankInterProject);
        // $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectRequiredIns);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialAccBankInterProjectReason);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccBankInterProjectReasonInputF, "Test001");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCrtTaskBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->see("has been created and send.");
        $I->click(GlobalLocators::$PasswdCrAccBankInterProjectCloseBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ADMIN);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD_ADM);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtab);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$PasswdAccessControlTabCredentialAccControlSubtabAndApprove);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdAppExitBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$LogWithAnotherUsr);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$loginUserInput, self::USER_ORD);
        $I->fillField(GlobalLocators::$loginPassInput, self::PASSWORD);
        $I->click(GlobalLocators::$loginButton);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->click(GlobalLocators::$PasswdCredentialOSAccessTab);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$PasswdCredentialOSAccInputF);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$PasswdCredentialAccProject, "BANKINTER");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->see(GlobalLocators::$PasswdAccessControlTabCredentialAccControlImxProdRequest);
        $I->see(GlobalLocators::$PasswdAccessControlTabCredentialAccAsterix);
        $I->wait(GlobalParams::MID_WAIT);

    }
}
