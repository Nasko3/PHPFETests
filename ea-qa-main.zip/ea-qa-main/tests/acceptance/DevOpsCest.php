<?php

namespace Acceptance;

use \AcceptanceTester;
use Facebook\WebDriver\WebDriverKeys;
use \Facebook\WebDriver\WebDriverBy;
use GlobIterator;
use Locators\GlobalLocators;
use Models\AcceptanceCest;
use Params\GlobalParams;

class DevOpsCest extends AcceptanceCest
{
    private const PATH = ['PAS', 'DevOps Matrix'];
    public function _before(AcceptanceTester $I)
    {
        $this->signInUserManagment($I);
        $this->navigateToDevOpsApp($I);
    }

    // public function NavigateFromPASTo($I, $value)
    // {
    //     $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, $value));
    //     $I->wait(GlobalParams::MID_WAIT);
    // }

    /**
     * @group DevOpsCest
     * 
     */
    protected function navigateToPasAndCreateBuild(AcceptanceTester $I)
    {
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$DevOpsPASDropdown2);
        $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, "pas"));
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, "extranet"));
        $I->click(GlobalLocators::$devOpsTabExtranetBtnCreateBuild);
        $I->wait(GlobalParams::BIG_WAIT);
        $I->fillField(GlobalLocators::$DevOpsTabExtranetCreateBuildFieldBrunch, "IMB_LOKI_RL");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click("(//span[text()='IMB_LOKI_RL'])[1]");
        $I->wait(GlobalParams::SHORT_WAIT);

        $I->fillField(GlobalLocators::$DevOpsTabExtranetCTRBuildFieldClient, "IMB");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$DevOpsTabExtranetCTRBuildFieldInstance, "ivka");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->selectOption(GlobalLocators::$DevOpsTabExtranetCTRBuildDropDownDeployOn, "Tomcat 9.0.53 jdk8");
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$DevOpsTabExtranetBtnStartCrtBld);
        // $I->click(GlobalLocators::DevOpsPasTabDevOpsMatrix));
        //$this->navigateModule($I, self::PATH);
        // $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, $module));
        // $this->generateLocator(GlobalLocators::$devOpsBoard, $module);
        //$I->wait(100);
        $I->waitForText("Verifying build is running", 45);
    }

    /**
     * @group DevOpsCest
     * 
     */

    public function navigateToPasAndCreateDebiteurBuild(AcceptanceTester $I)
    {
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$DevOpsPASDropdown2);
        $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, "pas"));
        $I->wait(GlobalParams::MID_WAIT);
        $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, "debiteur"));
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebiteurBtnNewBld);
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebiteurFldBranch);
        $I->click(GlobalLocators::$DevOpsTabDebDrDownBranch);
        $I->fillField(GlobalLocators::$DevOpsTabDebDrDownClient, "BOCCHIO");
        $I->click(GlobalLocators::$DevOpsTabDebDrDownBranchBochio);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->fillField(GlobalLocators::$DevOpsTabDebiteurFldInstance, "BONO");
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebStartBtn);
        $I->wait(GlobalParams::MID_WAIT);
        $I->wait(80);
        $I->waitForText("Build is running", 45);
    }
/**
 * Before started this TC, devops-ui must be set as alternative way of dev instance by flowing steps :
 * 1: docker build --tag devops-ui:local .
 * 2: docker-compose up --no-build --detach
 * no using please script until needed to back in local mode!
 */
    /**
     * @group DevOpsCest
     * 
     */
    public function navigateToPasDebiteurAndStartStopBuild(AcceptanceTester $I)
    {
        $I->click(GlobalLocators::$DevOpsPASDropdown2);
        $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, "pas"));
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->wait(GlobalParams::MID_WAIT);
        $originURL = $I->grabAttributeFrom("(//a[contains(@href,'devops/builds')])[1]", 'href');
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebStoptBtnOnRunningBuild);
        $I->wait(GlobalParams::MID_WAIT);
        $I->waitForElementVisible(GlobalLocators::$DevOpsTabDebStoppedBuild);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->openNewTab();
        $I->wait(GlobalParams::MID_WAIT);
        $I->amOnPage($originURL);
        $I->wait(GlobalParams::BIG_WAIT);
        $I->closeTab();
        $I->reloadPage();
        $I->waitForElementVisible(GlobalLocators::$DevOpsTabDebRunningBuild);
        $I->wait(GlobalParams::MID_WAIT);
    }

    /**
     * @group DevOpsCest
     * 
     */

    public function navigateToPasDebiteurAndDownloadBuild(AcceptanceTester $I)
    {
        $I->click(GlobalLocators::$DevOpsPASDropdown2);
        $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, "pas"));
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, "debiteur"));
        $I->wait(GlobalParams::MID_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebDownloadBuild);
        $I->wait(GlobalParams::MID_WAIT);
    }

    /**
     * @group DevOpsCest
     * 
     */

    public function navigateToPasDebiteurAndDeleteBuild(AcceptanceTester $I)
    {
        $I->click(GlobalLocators::$DevOpsPASDropdown2);
        $I->click($this->generateLocator(GlobalLocators::$DevOpsConfig, "pas"));
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click($this->generateLocator(GlobalLocators::$devOpsBoard, "debiteur"));
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebRemoveBtn);
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->see('Are you sure you what to remove');
        $I->wait(GlobalParams::SHORT_WAIT);
        $I->click(GlobalLocators::$DevOpsTabDebRemovePopUpBtn);
        $I->dontSee('boc-db-grom-bocchio-hawk');
        // $I->performOn("modal-overlay",function(\Codeception\Module\WebDriver $I){
        //     $I->see('Are you sure you what to remove');
        //     $I->click('Remove');
        // });
    }

}