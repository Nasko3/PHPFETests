function get_captcha(image_data, callback){
    image_data = image_data.replace(/^data:image\/(png|jpg|jpeg|gif);base64,/, "")
    const params = {
        userid:'inj.a.georgiev@gmail.com',
        apikey:'NaJHuqXSxCFynb5MagYQ',
        data:   image_data,
    }
    const url = "https://api.apitruecaptcha.org/one/gettext"

    fetch(url, {
        method: 'post',
        body: JSON.stringify(params)
    })
    .then((response) => response.json())
    .then((data) => callback(data));
}