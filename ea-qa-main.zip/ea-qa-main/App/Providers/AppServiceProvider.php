<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Exception;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register app services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
