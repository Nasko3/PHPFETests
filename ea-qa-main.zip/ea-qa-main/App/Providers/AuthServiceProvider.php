<?php

namespace App\Providers;

class AuthServiceProvider extends \Core\Providers\AuthServiceProvider
{
    /**
     * Register policies.
     *
     * @return void
     */
    public function registerPolicies()
    {
        //Gate::policy('extranet', ExtranetPolicy::class);
    }
}
