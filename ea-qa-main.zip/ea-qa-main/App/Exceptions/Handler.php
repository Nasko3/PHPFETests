<?php

namespace App\Exceptions;

class Handler extends \Core\Exceptions\Handler
{

}
