<?php

namespace App\Console;

use Acceptance\DevOpsCest;
use Acceptance\DevOpsRunner;
use Acceptance\PasswdCestRunner;
use codixSite\CodixSiteRunner;
use Illuminate\Console\Scheduling\Schedule;
use Laravel\Lumen\Console\Kernel as ConsoleKernel;
use tests\codixSite\CodixSiteCest;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        CodixSiteRunner::class,
        DevOpsRunner::class,
        PasswdCestRunner::class,
        //AuditCommand::class,
        //Generate::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('check:requestForDemo')
            ->weeklyOn(1, '14:00')
            ->emailOutputTo('ageorgiev@codix.eu')
            ->appendOutputTo(storage_path("logs/demositetest.log"));

        $schedule->command('check:DevOpsCest')
            ->weeklyOn(1, '14:00')
            ->emailOutputTo('ageorgiev@codix.eu')
            ->appendOutputTo(storage_path("logs/devopstests.log"));

        $schedule->command('check:PasswdCest')
            ->weeklyOn(1, '14:00')
            ->emailOutputTo('ageorgiev@codix.eu')
            ->appendOutputTo(storage_path("logs/passwdtests.log"));

        $schedule->command('schedule:clear-cache')
            ->everyTwoHours();
    }
}
