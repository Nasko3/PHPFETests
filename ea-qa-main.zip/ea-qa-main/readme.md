# ea-qa-automation management


# Installation

```
git clone {url}
```

# Configuration

Just copy **.env.example** file in **.env**

# Run with Docker
```
./start.sh 
```

You can adjust containers settings in **docker-compose.yml** file


# Testing

All tests are located in **tests** directory

```
composer test

// run just the functional tests
composer test:functional

// run just the unit tests
composer test:unit 
```

If running docker: 
```
./scripts/composer.sh test
```
