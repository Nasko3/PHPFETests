<?php
$app = require __DIR__ . '/../vendor/laravel/lumen-framework/config/app.php';

return array_merge(
    $app,
    [
        'timezone' => env('APP_TIMEZONE'),

        /*
        |--------------------------------------------------------------------------
        | Application code
        |--------------------------------------------------------------------------
        | User Management application code. Used to get application info from DB
        |
        */
        'application_code' => env('APP_CODE'),

        /*
        |--------------------------------------------------------------------------
        | JWT settings
        |--------------------------------------------------------------------------
        |
        | Here you may configure the ldSWT settings for your application.
        |
        */
        'jwt' => [
            'public_key'             => env('JWT_PUBLIC_KEY', 'ssh/id_rsa.pub'),
            'algorithms'             => explode(',', env('JWT_ALGORITHMS', 'RS256')),
            'dont_check_in_local_db' => env('JWT_DONT_CHECK_IN_LOCAL_DB', false)
        ],

        /*
        |--------------------------------------------------------------------------
        | Mail settings
        |--------------------------------------------------------------------------
        |
        */
        // send notification mails for problems
        'admin-mails' => explode(',', env('ADMIN_MAILS', 'phpid@codixfr.private')),

        // if not production all mails will be send to this addresses
        'test-mails'  => explode(',', env('TEST_MAILS', 'phpid@codixfr.private')),

        // send mail for new demo requests to this addresses
        'demo-mails'  => explode(',', env('DEMO_MAILS', 'phpid@codixfr.private')),

        /*
        |--------------------------------------------------------------------------
        | User Management
        |--------------------------------------------------------------------------
        |
        | Connection to user management system for login and automation requests
        |
        */
        'user-management' => [
            'url'      => env('USER_MANAGEMENT_URL'),
            'username' => env('USER_MANAGEMENT_USERNAME'),
            'password' => env('USER_MANAGEMENT_PASSWORD'),
            'code'     => env('USER_MANAGEMENT_CODE')
        ],

        /*
        |--------------------------------------------------------------------------
        | Automation User
        |--------------------------------------------------------------------------
        |
        | This user is used to connect to different servers if needed
        |
        */
        'automation_username' => env('AUTOMATION_USERNAME'),
        'automation_rsa_key' => env('AUTOMATION_RSA_KEY'),
    ]
);
