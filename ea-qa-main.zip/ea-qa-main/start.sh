#!/bin/bash

# Install php dependencies
please composer install
